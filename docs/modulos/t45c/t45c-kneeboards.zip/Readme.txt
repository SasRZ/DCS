T-45C Checklist - Updated 17 October 2025

Realistic checklist, cockpit diagram, and quickstart guide for the freeware Goshawk mod.

CHANGELOG

17 October 2025
- Reworked to support version 1.2 of the mod.

14 May 2021
- Initial release.

DESCRIPTION

This is a fairly realistic checklist for the T-45C freeware mod available here:
https://forum.dcs.world/topic/203816-vnao-t-45-goshawk/page/61/#findComment-5705675

It follows NATOPS documents as closely as practicable for the DCS environment and is compatible with both carrier and shore ops. Speaking of the latter, if you're going to use the Goshawk in its natural habitat, you might want to grab my CASE-I/II/III kneeboards as well:
https://www.digitalcombatsimulator.com/en/files/3314314/

Finally, I recommend binding the following actions to your HOTAS or keyboard:
* COM PTT - COM1 (the comms menu).
* Exterior Lights Master FORWARD and AFT (located on the left side of the throttle grip and can be hard to reach).
* Gas Turbine Starter Button (also on the throttle, also hard to reach).
* Engine Switch START (it has to be held during startup).
* Throttle Finger Lift (pressing it will move the throttle to idle, completing the start sequence).

HOW TO INSTALL

Extract the downloaded archive, then copy the "T-45" folder into your "Saved Games\DCS (or DCS.openbeta)\KNEEBOARD\" directory. You may need to create the "KNEEBOARD" folder if it doesn't exist.

LATEST VERSION ON THE WEB

* PDF, day - https://dimon.one/dimon/files/T-45C_Checklist_Day_by_DimOn_latest.pdf
* PDF, night - https://dimon.one/dimon/files/T-45C_Checklist_Night_by_DimOn_latest.pdf
* Images - https://dimon.one/dimon/files/T-45C_Checklist/

CONTACT INFO

Created by Dima Kozyrev
dimkzr@gmail.com
